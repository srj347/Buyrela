package com.example.firestore.Modal;

import com.example.firestore.Food;
import com.example.firestore.MapAddress;
import com.example.firestore.User;

public class Common
{
        public static User user;
        public static Food food;
        public  static Cart cart;
        public static Useraddress useraddress;
        public static MapAddress MAP;
        public static int my_int;
}
