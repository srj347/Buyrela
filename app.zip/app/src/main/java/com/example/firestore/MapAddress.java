package com.example.firestore;

public class MapAddress
{
    public String map;

    public MapAddress(String map) {
        this.map = map;
    }

    public MapAddress() {
    }

    public String getMap() {
        return map;
    }

    public void setMap(String map) {
        this.map = map;
    }
}
