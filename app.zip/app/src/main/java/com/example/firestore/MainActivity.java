package com.example.firestore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.firestore.Modal.Cart;
import com.example.firestore.Modal.Common;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    public Intent intent;
    public FirebaseFirestore firebaseFirestore;
    public CollectionReference collectionReference;
    public TextView price;
    public ImageView imageView;
    public TextView quantity1;
    public TextView name;
    public ElegantNumberButton enb;
    public double rs;
    public double x;
    public double quantity;
    public Button button;
    public String name1;
    public String link1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_details_activity);
        //intent = getIntent();
        firebaseFirestore = FirebaseFirestore.getInstance();
        quantity = 0.25;
//        collectionReference = firebaseFirestore.collection("users")
//                .document(""+intent.getStringExtra("USER1")+intent.getStringExtra("USER2"))
//                        .collection("orders");
        collectionReference = firebaseFirestore.collection("users").document(Common.user.getName() + Common.user.getPhone()).collection("orders");


        name1 = Common.food.getName();
        link1 = Common.food.getLink();
        x = (double)Common.food.getKey();

        Toast.makeText(MainActivity.this, "THis", Toast.LENGTH_SHORT).show();
        quantity1 = findViewById(R.id.quantity);
        enb = findViewById(R.id.enb);
        button = findViewById(R.id.id_add);
        price = findViewById(R.id.price);
        name = findViewById(R.id.heading);
        name.setText(name1);
        imageView = findViewById(R.id.vege);
        Picasso.get().load(link1).into(imageView);
        price.setText("Rs. "+x);
        enb.setOnClickListener(new ElegantNumberButton.OnClickListener() {
            @Override
            public void onClick(View view) {
                String num = enb.getNumber();
                rs = (Double.parseDouble(num))*(x/4);
                price.setText("Rs. "+rs);
                quantity = Double.parseDouble(num)*(0.25);
                quantity1.setText(quantity + " Kg");
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                model model1 = new model(rs, name1);
//                collectionReference.document("order1").set(model1);
                Cart cart = new Cart(String.valueOf(rs), String.valueOf(quantity),name1,link1);
                collectionReference.document(name1).set(cart);
                Toast.makeText(MainActivity.this, "Order", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
