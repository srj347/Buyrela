package com.example.firestore;

public class getUser
{
    public static User USER;
}
