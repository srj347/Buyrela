package com.example.firestore.adapter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.firestore.Modal.Cart;
import com.example.firestore.Modal.Common;
import com.example.firestore.R;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firestore.v1.WriteResult;
import com.squareup.picasso.Picasso;

import static android.view.View.*;

public class Cart_Adapter extends FirestoreRecyclerAdapter<Cart, Cart_Adapter.CartViewHolder> {

    public double rs;
    public double x;
    public double quantity_kg;
    public Button button;
    public DocumentReference documentReference;
    public FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    public Cart_Adapter(@NonNull FirestoreRecyclerOptions<Cart> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final CartViewHolder cartViewHolder, int i, @NonNull final Cart cart) {
        cartViewHolder.name.setText(cart.getName());
        cartViewHolder.quantity.setText("Quantity:  "+cart.getQuantity()+" Kg");
        cartViewHolder.price.setText("Price: Rs. "+cart.getPrice());
        Picasso.get().load(cart.getLink()).into(cartViewHolder.thumbnail);
        //String number_enb = String.valueOf(Integer.parseInt(cart.getQuantity())*4);
        /*Integer integer = Integer.parseInt(cart.getQuantity().trim());
        integer = integer*4;*/

        Double my_double = Double.parseDouble(cart.getQuantity());
        my_double = my_double*4;
        Log.d("Double", "double"+my_double);
        int kuch_bhi = (int) Math.round(my_double);
        cartViewHolder.elegantNumberButton.setNumber(String.valueOf(kuch_bhi));
        cartViewHolder.elegantNumberButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                documentReference = firebaseFirestore.collection("users").document(Common.user.getName()+Common.user.getName()).collection("orders").document(cart.getName());
                x = Double.parseDouble(cart.getPrice());
                String num = cartViewHolder.elegantNumberButton.getNumber();
                rs = (Double.parseDouble(num))*(x/4);
                Log.d("DOUBLE", "doubledoubel"+rs);
                documentReference.update("price", rs);
                Toast.makeText(v.getContext(), ""+rs, Toast.LENGTH_SHORT).show();
                quantity_kg = Double.parseDouble(num)*(0.25);
                documentReference.update("quantity", quantity_kg);
                notifyDataSetChanged();
            }
        });

        cartViewHolder.view.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder ad = new AlertDialog.Builder(cartViewHolder.view.getContext());
                ad.setTitle("Want to delete");
                ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        delete(cartViewHolder.getAdapterPosition());
                    }
                });
                ad.show();
                return true;
            }
        });

    }
    public void delete(int position){
        getSnapshots().getSnapshot(position).getReference().delete();
    }


    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item_constraint, parent, false);
        return new CartViewHolder(view);
    }

    public class CartViewHolder extends RecyclerView.ViewHolder{
        TextView name ;
        TextView quantity;
        TextView price;
        ElegantNumberButton elegantNumberButton;
        ImageView thumbnail;
        View view ;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.vege_name);
            price = itemView.findViewById(R.id.price);
            elegantNumberButton = itemView.findViewById(R.id.enb);
            quantity = itemView.findViewById(R.id.quantity);
            thumbnail = itemView.findViewById(R.id.imageView2);
            view = itemView;

        }
    }
}
