package com.example.firestore;

import com.google.firebase.firestore.auth.User;

public class getUser
{
    public static user USER;
}
