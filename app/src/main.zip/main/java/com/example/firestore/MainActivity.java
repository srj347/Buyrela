package com.example.firestore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    public Intent intent;
    public FirebaseFirestore firebaseFirestore;
    public CollectionReference collectionReference;
    public TextView price;
    public ImageView imageView;
    public TextView name;
    public ElegantNumberButton enb;
    public int rs;
    public int x;
    public Button button;
    public String name1;
    public String link1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_details_activity);
        intent = getIntent();
        firebaseFirestore = FirebaseFirestore.getInstance();

        collectionReference = firebaseFirestore.collection("users")
                .document(""+intent.getStringExtra("USER1")+intent.getStringExtra("USER2"))
                        .collection("orders");
        

        name1 = intent.getStringExtra("name");
        link1 = intent.getStringExtra("link");
        x = intent.getIntExtra("key", 0);


        Toast.makeText(MainActivity.this, "THis", Toast.LENGTH_SHORT).show();
        enb = findViewById(R.id.enb);
        button = findViewById(R.id.id_add);
        price = findViewById(R.id.price);
        name = findViewById(R.id.heading);
        name.setText(name1);
        imageView = findViewById(R.id.vege);
        Picasso.get().load(link1).into(imageView);
        price.setText("Rs. "+x+".00");
        enb.setOnClickListener(new ElegantNumberButton.OnClickListener() {
            @Override
            public void onClick(View view) {
                String num = enb.getNumber();
                rs = (Integer.parseInt(num))*x;
                price.setText("Rs. "+rs+".00");
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                model model1 = new model(rs, name1);
                collectionReference.document("order1").set(model1);
            }
        });
    }
}
