package com.example.firestore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.auth.User;

public class login_activity extends AppCompatActivity {
    public String name1;
    public String phone1;
    public EditText name;
    public EditText phone;
    public Button login;
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    CollectionReference collectionReference = firebaseFirestore.collection("users");
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activity);
        name = findViewById(R.id.name);
        phone = findViewById(R.id.editText);
        login = findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                user USER = new user();
                     name1 = name.getText().toString().trim();
                     phone1 = phone.getText().toString().trim();
                     USER.setName(name1);
                     USER.setPhone(phone1);
                collectionReference.document(""+name1+phone1).set(USER);
                Intent intent = new Intent(login_activity.this, Main3Activity.class);
                intent.putExtra("name1", name1);
                intent.putExtra("phone1", phone1);
                Toast.makeText(login_activity.this, name1+phone1, Toast.LENGTH_SHORT).show();
//                intent.putExtra("USER1", USER.getName());
//                intent.putExtra("USER2", USER.getPhone());
                startActivity(intent);
            }
        });
    }
}

