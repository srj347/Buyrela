package com.example.firestore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class My_basket extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_basket);
    }
}